master_doc = 'pam_python'
project = u'pam_python'
copyright = u'2010,2014,2016,2019,2020, Russell Stuart'
version = '1.0.8'
release = '1.0.8'
extensions = ['sphinx.ext.intersphinx']
intersphinx_mapping = {'python': ('http://docs.python.org/2.7', None)}
